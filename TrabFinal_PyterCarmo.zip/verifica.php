<?php
session_start();

$login=$_POST["login"];
$senha=$_POST["senha"];

include_once "servico/Bd.php";
        
$bd = new Bd();
$sql = "select * from usuario where login='$login' and senha='$senha'";


$resultado = $bd->query($sql);
$logado = $resultado->fetch();
$id_logado = $logado['id'];

if ($logado == null) {
    session_destroy ( ) ;
    $html ="
    <html>
        <head><title>Tela de verificação </title></head>
        <body>
            <script>
                window.alert('Usuário ou senha incorretos!'); 
                window.location.replace('https://pytercs.000webhostapp.com/TrabFinal/janelalogin.html');
            </script>
        </body>
    </html>
";
   
}else {
    $_SESSION["autenticado"]=true;
    
    $html ="
    <html>
        <head><title>Tela de verificação </title></head>
        <body>
             <script>
                window.location.replace('https://pytercs.000webhostapp.com/TrabFinal/menu.php');
             </script>
        </body>
    </html>

";    
    
}

echo $html;
?>