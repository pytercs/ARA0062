<?php

include_once "../servico/Bd.php";

$login=$_GET["login"];
$senha=$_GET["senha"];

if (isset($_GET["id"])) { //atualiza
    $id = $_GET["id"];
    $sql = "update `usuario` set login='$login', senha='$senha' where id='$id' ";
    $bd = new Bd();
    $contador = $bd->exec($sql);
    $html1 ="
    <html>
        <body>
            <script>
                window.alert('$contador Usuário atualizado com sucesso!'); 
                window.location.replace('https://pytercs.000webhostapp.com/TrabFinal/menu.php');
            </script>
        </body>
    </html>
";
echo $html1;
}else { //grava um novo
    $sql = "INSERT INTO `usuario` (`id`, `login`, `senha`) VALUES (NULL, '$login', '$senha')";    
}
$bd = new Bd();
    $contador = $bd->exec($sql);
$html2 ="
    <html>
        <body>
            <script>
                window.alert('$contador Usuário criado com sucesso!'); 
                window.location.replace('https://pytercs.000webhostapp.com/TrabFinal/menu.php');
            </script>
        </body>
    </html>
";
echo $html2;

?>
