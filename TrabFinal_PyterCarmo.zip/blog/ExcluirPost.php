<?php

include_once "../servico/Bd.php";

$id=$_GET["id"];

$sql = "delete from blog where id='$id' ";
$bd = new Bd();
$contador = $bd->exec($sql);

$html ="
    <html>
        <body>
            <script>
                window.alert('$contador Postagem excluída com sucesso!'); 
                window.location.replace('https://pytercs.000webhostapp.com/TrabFinal/menu.php');
            </script>
        </body>
    </html>
";
echo $html;

?>

