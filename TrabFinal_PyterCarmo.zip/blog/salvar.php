<?php

include_once "../servico/Bd.php";

$titulo=$_GET["titulo"];
$corpo=$_GET["corpo"];

if (isset($_GET["id"])) { //atualiza
    $id = $_GET["id"];
    $sql = "update `blog` set titulo='$titulo', corpo='$corpo' where id='$id' ";
    $bd = new Bd();
    $contador = $bd->exec($sql);
    $html1 ="
    <html>
        <body>
            <script>
                window.alert('$contador Postagem atualizada com sucesso!'); 
                window.location.replace('https://pytercs.000webhostapp.com/TrabFinal/menu.php');
            </script>
        </body>
    </html>
";
echo $html1;

}else { //grava um novo
    $sql = "INSERT INTO `blog` (`id`, `titulo`, `corpo`) VALUES (NULL, '$titulo', '$corpo')";    
}
$bd = new Bd();
    $contador = $bd->exec($sql);
$html2 ="
    <html>
        <body>
            <script>
                window.alert('$contador Postagem criada com sucesso!'); 
                window.location.replace('https://pytercs.000webhostapp.com/TrabFinal/menu.php');
            </script>
        </body>
    </html>
";
echo $html2;
?>

