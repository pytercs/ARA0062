<?php
//sem segurança

include_once "../servico/Bd.php";

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css">
    <title>Gerenciamento de Postagens</title>
  </head>
  <body>
      <header>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.html"><i class="fas fa-film" aria-hidden="true"></i></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item ">
        <a class="nav-link" href="../menu.php">Início <span class="sr-only"></span></a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="IncluirPost.php">Nova Postagem <span class="sr-only"></span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="ConsultaPost.php">Todas as Postagens <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="../usuario/IncluirUsuario.php">Novo usuário <span class="sr-only"></span></a>
      </li>
    </ul>
    <div class="my-2 my-md-0 d-flex justify-content-end align-items-center">
        <a class="btn btn-sm btn-outline-light" href="index.html">Sair </a>
    </div>
      </div>
</nav>
</header>
<br><br>
      <div class="container">
        <h1>Todas as Postagens</h1>
        <hr>
    <div class="container">
        <br><br>
        
        <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Id</th>
                <th>Título</th>
                <th>Postagem</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
             <?php
        
           $bd = new Bd();
           $sql = "select * from blog";
           
           foreach ($bd->query($sql) as $row) {
                echo "<tr>";
                echo "<td>". $row['id'] . "</td>";
                echo "<td>". $row['titulo'] . "</td>";
                echo "<td>". $row['corpo'] . "</td>";
                
                echo "<td><a href=# onclick ='Pergunta(". $row['id'] . ")'> Excluir</a></td>";
                
                echo "<td><a href='AlterarPost.php?id=". $row['id'] . "'>Alterar</a></td>";
                echo "</tr>";
            }
           
        
         ?>
        </tbody>
        <tfoot>
            <tr>
                <th>Id</th>
                <th>Título</th>
                <th>Postagem</th>
                 <th></th>
                <th></th>
            </tr>
        </tfoot>
    </table>
    
        
        <script>
        function Pergunta(id) {

          if (confirm("Deseja realmente excluir ?")) {
            window.location.replace("https://pytercs.000webhostapp.com/TrabFinal/blog/ExcluirPost.php?id="+id);

          }
        }
        </script>

       
    
    
    </div>
    
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
    
     <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
     <script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
     
     <script>
         
         $(document).ready(function() {
            $('#example').DataTable();
        } );

     </script>
     
  </body>
</html>